package com.mainproject.NotificationService.Services;


import org.springframework.stereotype.Service;



public class FirebaseMessagingService {
//    private final FirebaseMessaging firebaseMessaging;
//
//    public FirebaseMessagingService(FirebaseMessaging firebaseMessaging) {
//        this.firebaseMessaging = firebaseMessaging;
//    }
//
//
//    public void sendNotification(String title, String body, String token) throws FirebaseMessagingException {
//
//        Notification notification = Notification
//                .builder()
//                .setTitle(title)
//                .setBody(body)
//                .build();
//
//        Message message = Message
//                .builder()
//                .setToken(token)
//                .setNotification(notification)
////              .putAllData(note.getData())
//                .build();
//        firebaseMessaging.send(message);
//
//// For Send to multiple devices use Multicast Message Builder
//
////        MulticastMessage messages = MulticastMessage
////                .builder()
////                .addAllTokens(<List Of Tokens>)
////                .setNotification(notification)
//////              .putAllData(note.getData())
////                .build();
////        firebaseMessaging.send(message);
//    }

}
