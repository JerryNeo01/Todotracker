package com.mainproject.NotificationService.Domain;

public class UserInfoSDTO {

    private String email ;


    private String firstname;

    private String profileimg;
}
