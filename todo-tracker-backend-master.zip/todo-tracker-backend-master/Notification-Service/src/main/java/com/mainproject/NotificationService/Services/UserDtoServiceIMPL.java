package com.mainproject.NotificationService.Services;

import com.mainproject.NotificationService.Domain.ToDo_DTO;
import com.mainproject.NotificationService.Domain.UsersDTO;
import com.mainproject.NotificationService.Exception.UserAlreadyExist;
import com.mainproject.NotificationService.Exception.UserNotFound;
import com.mainproject.NotificationService.Repository.UserRepos;
import org.springframework.beans.factory.annotation.Autowired;
import freemarker.template.Configuration;
import freemarker.template.Template;
import org.springframework.boot.actuate.autoconfigure.metrics.export.wavefront.WavefrontProperties;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import javax.mail.internet.MimeMessage;
import java.nio.charset.StandardCharsets;


@Service
public class UserDtoServiceIMPL implements UsersDtoServiceInterface {

    @Autowired
    private UserRepos userRepos;


//    @Override
//    public UsersDTO addUser(UsersDTO usersDTO) {
////        if(userRepos.findById(usersDTO.getEmail()).isPresent()){
////            ret
////        }else {
//            return userRepos.save(usersDTO);
////        }
//
//    }

    @Autowired
    private JavaMailSender mailSender;
    @Autowired
    private Configuration config;
    @Override
    public void welcomeMail(UsersDTO usersDTO) throws UserNotFound{
        MimeMessage message= mailSender.createMimeMessage();

        try {
            System.out.println("sending email");
            //SimpleMailMessage message = new SimpleMailMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED, StandardCharsets.UTF_8.name());

            //helper.addAttachment("logo.png", new ClassPathResource("logo.png"));
            Template t = config.getTemplate("welcome.ftl");
            String html = FreeMarkerTemplateUtils.processTemplateIntoString(t, usersDTO);

            helper.setFrom("todotracker01@gmail.com");
            helper.setTo(usersDTO.getEmail());
            helper.setText(html,true);
            helper.setSubject("Todo Tracker Welcome");

            mailSender.send(message);
            System.out.println("Mail Send...");
        }catch (Exception e){
            throw new UserNotFound();
        }
    }

    @Override
    public void verification(UsersDTO usersDTO) throws UserNotFound {
        MimeMessage message= mailSender.createMimeMessage();

        try {
            System.out.println("sending email");
            //SimpleMailMessage message = new SimpleMailMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED, StandardCharsets.UTF_8.name());

            //helper.addAttachment("logo.png", new ClassPathResource("logo.png"));
            Template t = config.getTemplate("email-verify.ftl");
            String html = FreeMarkerTemplateUtils.processTemplateIntoString(t, usersDTO);
            //SimpleMailMessage message = new SimpleMailMessage();
            helper.setFrom("todotracker01@gmail.com");
            helper.setTo(usersDTO.getEmail());
//            helper.setText("Hello " + usersDTO.getFirstname() + "\nWelcome to Todo Tracker\nTo Verify Your email Click Here http://localhost:4200/verified/" + usersDTO.getEmail());
            helper.setText(html,true);
            helper.setSubject("Todo Tracker Verification");
            mailSender.send(message);
            System.out.println("Mail Send...");
        }catch (Exception e){
            System.out.println(e);
            throw new UserNotFound();
        }

    }

    @Override
    public String otpSender(UsersDTO usersDTO) throws UserNotFound{
        MimeMessage message= mailSender.createMimeMessage();

        try {
            System.out.println("sending email");


            //SimpleMailMessage message = new SimpleMailMessage();
            MimeMessageHelper helper= new MimeMessageHelper(message,MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED, StandardCharsets.UTF_8.name());

            //helper.addAttachment("logo.png", new ClassPathResource("logo.png"));
            Template t=config.getTemplate("otp-template.ftl");
            String html= FreeMarkerTemplateUtils.processTemplateIntoString(t,usersDTO);
            helper.setFrom("todotracker01@gmail.com");
            helper.setTo(usersDTO.getEmail());
            helper.setText(html,true);
            helper.setSubject("Todo Tracker OTP");
            mailSender.send(message);
            System.out.println("Mail Send...");
            return "Mail Send...";
        }catch (Exception e){
            System.out.println(e);
            throw new UserNotFound();
        }
    }

    @Override
    public void resetpassword(UsersDTO usersDTO) throws UserNotFound {

       try {
           System.out.println("sending email");

           SimpleMailMessage message = new SimpleMailMessage();

           message.setFrom("todotracker01@gmail.com");
           message.setTo(usersDTO.getEmail());
           message.setText("Hello " + usersDTO.getFirstname() + "\nYour Password reset is DONE\nYour Email is  : " + usersDTO.getEmail() + "\nYour Password is : " + usersDTO.getPassword());
           message.setSubject("Todo Tracker Password reset");
           mailSender.send(message);
           System.out.println("Mail Send...");
       }catch(Exception e){
           System.out.println(e);
           throw new UserNotFound();
       }



    }


//    public void settask(UsersDTO usersDTO){
////        ToDo_DTO toDo_dto= usersDTO.getToDo_dtoList();
//        SimpleMailMessage message=new SimpleMailMessage();
//        message.setFrom("todotracker01@gmail.com");
//        message.setTo(usersDTO.getEmail());
//        message.setText("Dear "+usersDTO.getFirstname()+",\nYou have added new task\nTitle : ");
//        message.setSubject("New Task is Added");
//    }


}
